Copyright (c) 2025 Maicon Bartoski

Permissão é concedida, gratuitamente, a qualquer pessoa que obtenha uma cópia deste software e dos arquivos de documentação associados (o "Software"), para modificar, criar novas ferramentas e distribuir as modificações, desde que:

1. Todas as modificações e novas ferramentas derivadas deste Software sejam compartilhadas publicamente sob esta mesma licença;
2. Seja atribuída a devida autoria ao criador original, Maicon Bartoski, incluindo um aviso claro de atribuição em qualquer redistribuição ou modificação do Software;
3. Esta permissão não inclui qualquer garantia de funcionalidade, adequação para um propósito específico ou responsabilidade por danos resultantes do uso deste Software.

O Software é fornecido "como está", sem garantias de qualquer tipo, expressas ou implícitas, incluindo, mas não se limitando a garantias de comercialização, adequação a um propósito específico e não violação. Em nenhum caso os autores ou detentores dos direitos autorais serão responsáveis por qualquer reclamação, dano ou outra responsabilidade, seja em ação contratual, ilícito ou de outra forma, decorrente de, ou em conexão com o Software ou o uso ou outras negociações no Software.

Ao utilizar, modificar ou distribuir este Software, você concorda com os termos desta licença.

